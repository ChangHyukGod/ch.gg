from django.contrib import admin
from .models import Post
# Register your models here.
#gitignore - https://gbsb.tistory.com/11
#github id = gyejr95@naver.com
#github pw = tlsalsdyd95!
#내 블로그 도메인 = gyejr95.pythonanywhere.com
#pythonanywhere 가상환경까지의 경로 /home/gyejr95/my-first-blog/myvenv
admin.site.register(Post)
