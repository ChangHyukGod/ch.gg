from django.apps import AppConfig


class ScoreConfig(AppConfig):
    name = 'score'
